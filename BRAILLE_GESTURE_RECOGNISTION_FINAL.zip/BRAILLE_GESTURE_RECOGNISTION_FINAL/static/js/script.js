// Global JavaScript functions for Sign2Braille

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    // Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add loading animations
    const loadingSpinner = document.createElement('div');
    loadingSpinner.className = 'loading-spinner';
    loadingSpinner.innerHTML = '<i class="fas fa-spinner fa-spin fa-3x"></i>';
    loadingSpinner.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 9999;
        display: none;
    `;
    document.body.appendChild(loadingSpinner);

    // Show loading spinner on form submissions
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function() {
            loadingSpinner.style.display = 'block';
        });
    });

    // Page loading animation
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s ease';
        document.body.style.opacity = '1';
    }, 100);
});

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
    `;
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(notification);

    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

// Braille pattern generator utility
class BrailleUtils {
    static generatePattern(character) {
        const patterns = {
            'A': [[1,0],[0,0],[0,0]], 'B': [[1,0],[1,0],[0,0]], 'C': [[1,1],[0,0],[0,0]],
            'D': [[1,1],[0,1],[0,0]], 'E': [[1,0],[0,1],[0,0]], 'F': [[1,1],[1,0],[0,0]],
            'G': [[1,1],[1,1],[0,0]], 'H': [[1,0],[1,1],[0,0]], 'I': [[0,1],[1,0],[0,0]],
            'J': [[0,1],[1,1],[0,0]], 'K': [[1,0],[0,0],[1,0]], 'L': [[1,0],[1,0],[1,0]],
            'M': [[1,1],[0,0],[1,0]], 'N': [[1,1],[0,1],[1,0]], 'O': [[1,0],[0,1],[1,0]],
            'P': [[1,1],[1,0],[1,0]], 'Q': [[1,1],[1,1],[1,0]], 'R': [[1,0],[1,1],[1,0]],
            'S': [[0,1],[1,0],[1,0]], 'T': [[0,1],[1,1],[1,0]], 'U': [[1,0],[0,0],[1,1]],
            'V': [[1,0],[1,0],[1,1]], 'W': [[0,1],[1,1],[0,1]], 'X': [[1,1],[0,0],[1,1]],
            'Y': [[1,1],[0,1],[1,1]], 'Z': [[1,0],[0,1],[1,1]], ' ': [[0,0],[0,0],[0,0]]
        };
        return patterns[character.toUpperCase()] || patterns[' '];
    }

    static renderPattern(pattern, container) {
        container.innerHTML = '';
        const table = document.createElement('div');
        table.className = 'braille-cell';
        
        pattern.forEach(row => {
            row.forEach(dot => {
                const dotElement = document.createElement('div');
                dotElement.className = `braille-dot ${dot ? 'filled' : ''}`;
                table.appendChild(dotElement);
            });
        });
        
        container.appendChild(table);
    }
}

// Export for global use
window.BrailleUtils = BrailleUtils;
window.showNotification = showNotification;