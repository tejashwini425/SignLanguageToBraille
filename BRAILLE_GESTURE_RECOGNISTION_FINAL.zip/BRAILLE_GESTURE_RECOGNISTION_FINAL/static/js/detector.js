// Detector functionality for Sign Language to Braille conversion
document.addEventListener('DOMContentLoaded', function() {
    // Camera functionality
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const landmarksOverlay = document.getElementById('landmarksOverlay');
    const startBtn = document.getElementById('startCamera');
    const stopBtn = document.getElementById('stopCamera');
    const detectBtn = document.getElementById('detectSign');
    const clearBtn = document.getElementById('clearText');
    const autoDetectCheckbox = document.getElementById('autoDetect');
    
    let stream = null;
    let autoDetectInterval = null;
    let isProcessing = false;
    let lastDetectionTime = 0;
    const DETECTION_COOLDOWN = 1000; // 1 second cooldown between detections

    // Load model information on page load
    loadModelInfo();

    function loadModelInfo() {
        fetch('/api/model_info')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('statusText').textContent = 
                        `Model loaded: ${data.model_loaded ? 'Yes' : 'No'}`;
                    document.getElementById('infoStatus').textContent = 
                        data.model_loaded ? 'Loaded' : 'Not Loaded';
                    document.getElementById('infoStatus').className = 
                        data.model_loaded ? 'badge bg-success' : 'badge bg-danger';
                    
                    // Update model info display
                    document.getElementById('infoActions').textContent = data.model_type || 'SVM Model';
                    
                    if (!data.model_loaded) {
                        showDetectionStatus('Model not loaded properly. Please check your model files.', 'error');
                    } else {
                        showDetectionStatus('SVM Model loaded successfully! Start camera to begin detection.', 'success');
                    }
                }
            })
            .catch(error => {
                console.error('Error loading model info:', error);
                showDetectionStatus('Error loading model information', 'error');
            });
    }

    function showDetectionStatus(message, type = 'info') {
        const statusDiv = document.getElementById('detectionStatus');
        statusDiv.textContent = message;
        statusDiv.className = `detection-status status-${type}`;
        statusDiv.style.display = 'block';
        
        if (type !== 'processing') {
            setTimeout(() => {
                statusDiv.style.display = 'none';
            }, 5000);
        }
    }

    function showDetectionInfo(message) {
        const infoDiv = document.getElementById('detectionInfo');
        const infoText = document.getElementById('detectionInfoText');
        infoText.textContent = message;
        infoDiv.style.display = 'block';
    }

    function hideDetectionInfo() {
        document.getElementById('detectionInfo').style.display = 'none';
    }

    function updateHandsStatus(handsDetected, numHands = 0) {
        const frameCounter = document.getElementById('frameCounter');
        const progressBar = document.getElementById('frameProgress');
        
        if (handsDetected) {
            frameCounter.innerHTML = `<i class="fas fa-hands text-success me-1"></i>Hands detected: ${numHands}`;
            progressBar.style.width = '100%';
            progressBar.style.background = '#27ae60';
        } else {
            frameCounter.innerHTML = '<i class="fas fa-hand-paper text-muted me-1"></i>Show your hands to detect signs';
            progressBar.style.width = '0%';
            progressBar.style.background = '#95a5a6';
        }
        
        document.getElementById('progressText').textContent = handsDetected ? 'Ready to detect' : 'No hands';
    }

    // Camera controls
    startBtn.addEventListener('click', async function() {
        try {
            stream = await navigator.mediaDevices.getUserMedia({ 
                video: { 
                    width: { ideal: 500 },
                    height: { ideal: 500 },
                    frameRate: { ideal: 15 }
                } 
            });
            video.srcObject = stream;
            startBtn.disabled = true;
            stopBtn.disabled = false;
            detectBtn.disabled = false;
            landmarksOverlay.classList.remove('d-none');
            
            showDetectionStatus('Camera started successfully!', 'success');
            showDetectionInfo('Show your hands to detect signs. Single frame detection enabled.');
            
            if (autoDetectCheckbox.checked) {
                startAutoDetection();
            }
        } catch (err) {
            console.error('Error accessing camera:', err);
            showDetectionStatus('Error accessing camera: ' + err.message, 'error');
        }
    });

    stopBtn.addEventListener('click', function() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            video.srcObject = null;
            startBtn.disabled = false;
            stopBtn.disabled = true;
            detectBtn.disabled = true;
            landmarksOverlay.classList.add('d-none');
            stopAutoDetection();
            showDetectionStatus('Camera stopped.', 'info');
            hideDetectionInfo();
            updateHandsStatus(false);
            isProcessing = false;
        }
    });

    // Auto-detection control
    autoDetectCheckbox.addEventListener('change', function() {
        if (this.checked && stream) {
            startAutoDetection();
        } else {
            stopAutoDetection();
        }
    });

    function startAutoDetection() {
        stopAutoDetection();
        autoDetectInterval = setInterval(() => {
            if (!detectBtn.disabled && !isProcessing) {
                detectSign();
            }
        }, 1000); // Detect every 1 second
    }

    function stopAutoDetection() {
        if (autoDetectInterval) {
            clearInterval(autoDetectInterval);
            autoDetectInterval = null;
        }
    }

    // Control buttons
    clearBtn.addEventListener('click', function() {
        fetch('/api/clear_buffer', { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateDetectionResult({
                        detected_char: '',
                        display_text: '',
                        confidence: 0,
                        sentence_braille_images: [],
                        hands_detected: false
                    });
                    showDetectionStatus('Text cleared successfully!', 'success');
                    hideDetectionInfo();
                    updateHandsStatus(false);
                }
            });
    });

    // Sign detection function
    function detectSign() {
        // Cooldown check to prevent too frequent requests
        const now = Date.now();
        if (now - lastDetectionTime < DETECTION_COOLDOWN) {
            return;
        }
        
        if (isProcessing) {
            return;
        }

        const context = canvas.getContext('2d');
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        isProcessing = true;
        lastDetectionTime = now;
        detectBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
        detectBtn.disabled = true;

        // Reduce image quality for faster transmission
        const imageData = canvas.toDataURL('image/jpeg', 0.7);
        
        fetch('/api/detect', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({image: imageData})
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                updateDetectionResult(data);
                
                // Update landmarks overlay
                if (data.image_with_landmarks) {
                    landmarksOverlay.src = 'data:image/jpeg;base64,' + data.image_with_landmarks;
                }
                
                // Update hands status
                updateHandsStatus(data.hands_detected, data.num_hands_detected || 0);
                
                // Show detection info
                if (data.detected_char) {
                    showDetectionInfo(`Detected: "${data.detected_char}" - Hands: ${data.num_hands_detected || 0}`);
                    showDetectionStatus('Sign detected successfully!', 'success');
                } else if (data.hands_detected) {
                    showDetectionInfo(`Hands detected: ${data.num_hands_detected || 0} - Ready for sign detection`);
                    showDetectionStatus('Hands detected, ready for sign recognition', 'info');
                } else {
                    showDetectionInfo('Show your hands to detect signs');
                    showDetectionStatus('No hands detected. Please show your hands.', 'info');
                }
            } else {
                showDetectionStatus('Detection failed: ' + (data.error || 'Unknown error'), 'error');
                // Still update landmarks if available
                if (data.image_with_landmarks) {
                    landmarksOverlay.src = 'data:image/jpeg;base64,' + data.image_with_landmarks;
                }
            }
        })
        .catch(error => {
            console.error('Detection error:', error);
            showDetectionStatus('Detection error: ' + error.message, 'error');
        })
        .finally(() => {
            detectBtn.innerHTML = '<i class="fas fa-search me-2"></i>Detect Sign';
            detectBtn.disabled = false;
            isProcessing = false;
        });
    }

    detectBtn.addEventListener('click', detectSign);

    // Update UI with detection results
    function updateDetectionResult(data) {
        // Update current character
        document.getElementById('detectedChar').textContent = data.detected_char || '-';
        document.getElementById('confidenceText').textContent = 
            `Confidence: ${parseFloat(data.confidence).toFixed(2)} %`;
        document.getElementById('confidenceBadge').textContent = `${parseFloat(data.confidence).toFixed(0)} %`;

        
        // Update confidence badge color
        const confidenceBadge = document.getElementById('confidenceBadge');
        if (data.confidence > 0.8) {
            confidenceBadge.className = 'badge bg-success float-end';
        } else if (data.confidence > 0.6) {
            confidenceBadge.className = 'badge bg-warning float-end';
        } else {
            confidenceBadge.className = 'badge bg-danger float-end';
        }
        
        // Update current braille image
        const currentBrailleImg = document.getElementById('currentBrailleImage');
        // if (data.current_char_image) {
        //     currentBrailleImg.src = 'data:image/png;base64,' + data.current_char_image;
        //     currentBrailleImg.style.display = 'block';
        // } else {
        //     currentBrailleImg.style.display = 'none';
        // }
        
        // Update sentence display
        document.getElementById('displayText').textContent = data.display_text || '-';
        document.getElementById('sentenceLength').textContent = data.sentence_length || 0;
        
        // Update braille display for sentence
        updateBrailleDisplay('sentenceBraille', data.display_text, data.sentence_braille_images);
        
        // Update detection history
        loadDetectionHistory();
    }

    function updateBrailleDisplay(containerId, text, brailleImages) {
        const container = document.getElementById(containerId);
        container.innerHTML = '';
        
        if (!text || text === '-') {
            container.innerHTML = '<div class="text-muted">No signs detected yet</div>';
            return;
        }
        
        if (brailleImages && brailleImages.length > 0) {
            // Use provided braille images
            let charIndex = 0;
            for (let i = 0; i < text.length; i++) {
                const char = text[i];
                if (char !== ' ') { // Skip spaces
                    if (charIndex < brailleImages.length) {
                        const letterDiv = document.createElement('div');
                        letterDiv.className = 'braille-letter';
                        
                        const charSpan = document.createElement('div');
                        charSpan.className = 'braille-char';
                        charSpan.textContent = char;
                        
                        const img = document.createElement('img');
                        img.src = 'data:image/png;base64,' + brailleImages[charIndex];
                        img.style.maxWidth = '40px';
                        img.alt = `Braille for ${char}`;
                        img.title = `Braille for ${char}`;
                        
                        letterDiv.appendChild(charSpan);
                        letterDiv.appendChild(img);
                        container.appendChild(letterDiv);
                        charIndex++;
                    }
                }
            }
        } else {
            // Fallback: display text characters
            for (let char of text) {
                if (char !== ' ') { // Skip spaces
                    const letterDiv = document.createElement('div');
                    letterDiv.className = 'braille-letter';
                    
                    const charSpan = document.createElement('div');
                    charSpan.className = 'braille-char';
                    charSpan.textContent = char;
                    
                    const placeholder = document.createElement('div');
                    placeholder.className = 'text-muted small';
                    placeholder.textContent = '⠼'; // Braille placeholder
                    placeholder.style.fontSize = '24px';
                    
                    letterDiv.appendChild(charSpan);
                    letterDiv.appendChild(placeholder);
                    container.appendChild(letterDiv);
                }
            }
        }
    }

    // Load detection history
    function loadDetectionHistory() {
        fetch('/api/history')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                const tableBody = document.getElementById('historyTable');
                tableBody.innerHTML = '';
                
                if (data.length === 0) {
                    tableBody.innerHTML = `
                        <tr>
                            <td colspan="4" class="text-center text-muted">
                                No detection history yet
                            </td>
                        </tr>
                    `;
                    return;
                }
                
                data.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td class="display-6 fw-bold">${item.sign || 'Unknown'}</td>
                        <td><code class="text-info">${item.braille_pattern || 'N/A'}</code></td>
                        <td>
                            <span class="badge bg-${item.confidence > 0.8 ? 'success' : item.confidence > 0.6 ? 'warning' : 'danger'}">
                                ${(item.confidence * 100).toFixed(1)}%
                            </span>
                        </td>
                        <td><small class="text-muted">${item.timestamp || 'Unknown'}</small></td>
                    `;
                    tableBody.appendChild(row);
                });
            })
            .catch(error => {
                console.error('Error loading history:', error);
                const tableBody = document.getElementById('historyTable');
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="4" class="text-center text-danger">
                            Error loading history
                        </td>
                    </tr>
                `;
            });
    }

    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        stopAutoDetection();
    });

    // Initial load
    loadDetectionHistory();
    updateHandsStatus(false);
});